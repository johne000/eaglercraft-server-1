#!/bin/bash
echo loading...
cd Bungee
java -Xmx1024M -Xms1024M -jar Bungee.jar
